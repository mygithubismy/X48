const fs = require('fs')
const express = require('express')
const path = require('path')
const hostname = '127.0.0.1'
const port = 80
const app = express()

app.use('/static', express.static('static')) // to serving static file
app.use(express.urlencoded())

app.set('view engine', 'pug') // to set Pug as Engine
app.set('views', path.join(__dirname, 'views')) // to views directory

app.get('/', (req, res)=>{res.status(200).render('index.pug')}) // get request

app.listen(port, ()=>{console.log(`The application running at ${hostname}:${port}`)})